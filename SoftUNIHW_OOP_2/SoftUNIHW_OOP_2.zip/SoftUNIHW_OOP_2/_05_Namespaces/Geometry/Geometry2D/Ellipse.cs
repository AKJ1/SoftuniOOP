﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftUNIHW_OOP_2._05_Namespaces.Geometry.Geometry2D
{
    class Ellipse
    {
    }
}
